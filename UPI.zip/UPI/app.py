import torch
import torch.nn as nn
from torchvision import models, transforms
from PIL import Image
# --- Flask and Login Imports ---
from flask import (Flask, request, jsonify, render_template, 
                   redirect, url_for, flash)
from flask_sqlalchemy import SQLAlchemy
from flask_login import (LoginManager, UserMixin, login_user, 
                       logout_user, login_required, current_user)
from flask_bcrypt import Bcrypt
import io
import os

# --- 1. Initialize App & Configs ---
# Create the Flask app instance FIRST
app = Flask(__name__)

# Configure the secret key and database location
app.config['SECRET_KEY'] = 'a_very_secret_key_change_this_123'
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'site.db')

# --- 2. Initialize Extensions ---
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'


# --- 3. Database Model ---
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(60), nullable=False)

    def __repr__(self):
        return f"User('{self.username}')"

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# --- 4. Model Loading & Prediction ---
MODEL_PATH = 'upi_model.pth'
CLASS_NAMES = ['Real', 'Fake']
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

model = models.mobilenet_v3_small(weights=None)
num_features = model.classifier[0].in_features
model.classifier = nn.Sequential(
    nn.Linear(num_features, 1024),
    nn.Hardswish(),
    nn.Dropout(p=0.2, inplace=True),
    nn.Linear(1024, 2)
)

try:
    model.load_state_dict(torch.load(MODEL_PATH, map_location=device))
    model = model.to(device)
    model.eval()
    print(f"✅ Model '{MODEL_PATH}' loaded successfully.")
except Exception as e:
    print(f"Error loading model: {e}")

prediction_transforms = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

def predict_image(image_bytes):
    try:
        image = Image.open(io.BytesIO(image_bytes)).convert('RGB')
        image_tensor = prediction_transforms(image).unsqueeze(0).to(device)
        with torch.no_grad():
            outputs = model(image_tensor)
            probabilities = torch.nn.functional.softmax(outputs, dim=1)
        confidence, predicted_idx = torch.max(probabilities, 1)
        predicted_class = CLASS_NAMES[predicted_idx.item()]
        return predicted_class, confidence.item()
    except Exception as e:
        print(f"Error processing image: {e}")
        return None, None

# --- 5. App Routes (Website Pages) ---

@app.route('/')
def home():
    """Serves the homepage"""
    return render_template('index.html')

@app.route('/detector')
@login_required  # Protects this page
def detector_page():
    """Serves the detector tool page"""
    return render_template('detector.html')
    
@app.route('/profile')
@login_required  # Protects this page
def profile():
    """Serves the user profile page"""
    return render_template('profile.html', user=current_user)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user_exists = User.query.filter_by(username=username).first()
        if user_exists:
            flash('Username already exists. Please choose another.', 'danger')
            return redirect(url_for('register'))
            
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        user = User(username=username, password=hashed_password)
        db.session.add(user)
        db.session.commit()
        
        flash('Your account has been created! You can now log in.', 'success')
        return redirect(url_for('login'))
        
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and bcrypt.check_password_hash(user.password, password):
            login_user(user, remember=True)
            flash('Login successful!', 'success')
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('home'))
        else:
            flash('Login unsuccessful. Please check username and password.', 'danger')
            
    return render_template('login.html')

@app.route("/logout")
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('home'))

# --- 6. App Route (API Endpoint) ---

@app.route('/predict', methods=['POST'])
@login_required  # Protects this API
def predict():
    """Handles the image upload and returns a prediction."""
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if file:
        try:
            image_bytes = file.read()
            label, confidence = predict_image(image_bytes)
            
            if label:
                return jsonify({
                    'prediction': label,
                    'confidence': f"{confidence*100:.2f}"
                })
            else:
                return jsonify({'error': 'Failed to process image'}), 500
                
        except Exception as e:
            return jsonify({'error': str(e)}), 500

# --- 7. Run the App ---
if __name__ == '__main__':
    # This block is essential!
    # It creates the database file if it doesn't exist.
    with app.app_context():
        db.create_all()
    
    app.run(debug=True)